//tipo number

const meuNumero = 11;

const telefone = 4484599619;

const idade = 17;


console.log(meuNumero);
console.log(telefone);
console.log(idade);


const soma = meuNumero + idade;

console.log(soma);
const minhaVar = 1;

const MinhaVar = 'Texto';

const minhavar = '3';

const MINHAVAR = 2;

console.log(minhaVar, MinhaVar, minhavar, MINHAVAR);





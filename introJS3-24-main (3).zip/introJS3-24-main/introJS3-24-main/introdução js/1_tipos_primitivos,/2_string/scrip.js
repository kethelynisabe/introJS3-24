const text1 = "Olá mundo";
const text2 = "Olá mundo";
const senha = "supersegura"

//concatenacao(+)

const citacao = "Meu nome é";
const meunome = "kethelyn"
console.log(citacao + meunome);

//compracao

console.log(text1 === text2);

const n1 = 1;
const n2 = 2;

console.log(n1 === n2);
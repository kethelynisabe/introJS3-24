//tipo number

const meuNumero = 11;

const telefone = 44984599619;

const idade = 17;


console.log(meuNumero);
console.log(telefone);
console.log(idade); 


const some = meuNumero + idade;

console.long(some);
const text1 = "Olá mundo";
const text2 = 'Olá mundo';
const senha = "senhasupersegura";
const stringDeNumeros = "3642";

//concatenacao (+)

const citacao = "Meu nome é ";
const meuNome = "Alan Reis "
console.log(citacao + meuNome);

//comparacao

console.log(text1 === text2);

const n1 = 1;
const n2 = 2;

console.log(n1 === n2);
const texto1 = "Kaike cupin";
const texto2 = 'gabziin.rs';

const texto3 = ' foi no "Banheiro"';

console.log(texto1);
console.log(texto2);
console.log(texto3);

console.log(texto2 + texto3);

const cifrao = '\u0024';
const aMaiusculo ='\u0041';

console.log(cifrao);
console.log(aMaiusculo);
let input = null;

if(input === null){
    console.log('não há informacao');
}else{
    console.log(input);
}

let input2;

console.log(input); // nulo
console.log(input2);